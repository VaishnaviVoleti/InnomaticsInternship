'''from flask import Flask, request, jsonify, render_template
import joblib
import re
import nltk
nltk.download('wordnet')
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer



# Initialize the Flask app
app = Flask(__name__)

# Load the fitted CountVectorizer from the training phase
count_vectorizer = joblib.load('count_vectorizer.pkl')

# Load the trained model
decision_tree_model = joblib.load('svm_model.pkl')

# Initialize the lemmatizer
lemmatizer = WordNetLemmatizer()

# Text preprocessing function
def preprocess(text):
    text = re.sub("[^a-zA-Z]", " ", text)
    text = text.replace('READ MORE', '')
    text = text.lower()
    words = word_tokenize(text)
    words = [word for word in words if word not in stopwords.words("english")]
    words = [lemmatizer.lemmatize(word) for word in words]
    preprocessed_text = " ".join(words)
    return preprocessed_text

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict_sentiment():
    new_review = request.form['review']
    
    preprocessed_review = preprocess(new_review)
    
    try:
        transformed_input = count_vectorizer.transform([preprocessed_review])

        prediction = decision_tree_model.predict(transformed_input)
        
        return jsonify({'sentiment': prediction[0]})
    except Exception as e:
        return jsonify({'error': str(e)})

# Run the app
if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0")  '''

from flask import Flask, request, render_template
import joblib
import re
import nltk
nltk.download('wordnet')
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer

# Initialize the Flask app
app = Flask(__name__)

# Load the fitted CountVectorizer from the training phase
count_vectorizer = joblib.load('count_vectorizer.pkl')

# Load the trained model
decision_tree_model = joblib.load('svm_model.pkl')

# Initialize the lemmatizer
lemmatizer = WordNetLemmatizer()

# Text preprocessing function
def preprocess(text):
    text = re.sub("[^a-zA-Z]", " ", text)
    text = text.replace('READ MORE', '')
    text = text.lower()
    words = word_tokenize(text)
    words = [word for word in words if word not in stopwords.words("english")]
    words = [lemmatizer.lemmatize(word) for word in words]
    preprocessed_text = " ".join(words)
    return preprocessed_text

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict_sentiment():
    new_review = request.form['review']
    
    preprocessed_review = preprocess(new_review)
    
    try:
        transformed_input = count_vectorizer.transform([preprocessed_review])

        prediction = decision_tree_model.predict(transformed_input)
        
        # Determine sentiment text and class for styling
        sentiment_text = "Positive 😍" if prediction[0] == 'positive' else "Negative 😒"
        sentiment_class = "positive" if prediction[0] == 'positive' else "negative"
        
        # Render result.html template with sentiment information
        return render_template('result.html', sentiment_text=sentiment_text, sentiment_class=sentiment_class)
    except Exception as e:
        return jsonify({'error': str(e)})

# Run the app
if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0")

