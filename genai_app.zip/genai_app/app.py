from openai import OpenAI
import streamlit as st

f = open("keys/.openai_api_key.txt")
key = f.read().strip()
client = OpenAI(api_key=key)

st.title("AI Code Reviewer🔍")
st.subheader("Check bugs and errors in your code here...")

prompt = st.text_area("Please give your code")

if st.button("Generate")==True:
    response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
            {"role": "system", "content": "Detect errors in the given code and provide the corrected code."},
            {"role": "user", "content": prompt} 
    ]
)
    st.write(response.choices[0].message.content)